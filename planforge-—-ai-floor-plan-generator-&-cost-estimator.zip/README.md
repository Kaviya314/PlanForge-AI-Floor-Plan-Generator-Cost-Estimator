# PlanForge — Describe. Design. Estimate.

> **AI-Powered Floor Plan Generator & Construction Cost Estimator**  
> *Turn your housing ideas into preliminary floor plans and transparent cost estimates.*

[![License: MIT](https://img.shields.io/badge/License-MIT-teal.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-7.0-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-19-cyan.svg)](https://react.dev/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-yellow.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-emerald.svg)](https://fastapi.tiangolo.com/)
[![Google Gemma](https://img.shields.io/badge/Google%20Gemma-4%20%2F%20GenAI-teal.svg)](https://ai.google.dev/gemma)

---

## 🏆 Hackathon Submission Categories

PlanForge was built by a 3rd-year Computer Science Engineering student for submission in two distinct hackathon challenge tracks:

1. **Best Open-Source AI Project**:
   - Clean, modular dual-stack architecture (React 19 + TypeScript frontend with Vector SVG CAD engine; Python FastAPI backend with Pydantic geometry validation).
   - Zero vendor lock-in, fully open-source under the permissive **MIT License**.
   - Comprehensive unit test suites (`pytest` for geometric collision and cost calculation; `tsc` for frontend typing).
   - Local browser persistence (LocalStorage) with JSON project import and export capabilities.

2. **Best Use of Gemma 4**:
   - Interprets natural language residential housing constraints (e.g., *"I want a 2BHK house on a 30 by 40 feet plot, with two bedrooms, two bathrooms, a kitchen, a living room, and a small balcony. My budget is ₹20 lakhs."*).
   - Uses strict structured schema generation to map human intent into non-overlapping 2D coordinates `[x, y, width, length]`.
   - Employs architectural reasoning to evaluate daylighting, cross-ventilation, and plumbing shaft clustering.
   - Configurable inference provider with graceful fallback to a deterministic architectural rule engine.

---

## 🛡️ Honest Engineering: Demo Mode vs Gemma AI Mode

PlanForge upholds strict hackathon integrity:

| Mode Badge | Trigger Condition | Engine Description |
|---|---|---|
| **Gemma AI Mode** *(Glowing Emerald)* | When an active `GEMINI_API_KEY` or valid Gemma 4 inference endpoint is configured. | Model extracts spatial constraints from natural language and synthesizes custom room arrangements and ventilation critiques. |
| **Demo Mode** *(Warm Amber)* | When running without an API key, offline, or when the user checks **"Force Demo Mode"**. | Uses a deterministic architectural rule heuristic engine to place rooms with guaranteed zero collision and standard municipal setback clearances. Never pretends to be AI. |

---

## 📐 Key Capabilities

### 1. Natural Language to 2D Layout
Describe any layout in ordinary English or configure structured plot dimensions (feet or metres), house types (1BHK, 2BHK, 3BHK, Custom), and budget constraints.

### 2. Interactive Vector CAD Canvas
- Real-time CAD drawing with fine 1 ft/m grid snapping.
- Distinct architectural pastel zoning fills (Living, Master Suite, Kitchen, Washrooms, Balcony).
- Realistic door swing arcs and exterior wall window fenestrations.
- Interactive drag-and-drop to reposition rooms with 0.5-unit grid snapping.
- Selected room inspector with dimension sliders and area calculation.
- One-click vector **SVG export**.

### 3. Programmatic Layout Validation Engine
Does not trust AI geometry blindly. Evaluates every plan across:
- **Bounds Checking**: Ensures all rooms stay strictly within plot boundaries `[0, 0]` to `[W, L]`.
- **Pairwise Collision Detection**: Flags spatial room intersections with highlighted hatching overlays.
- **Coverage Ratio**: Evaluates built-up ground coverage vs plot area; warns if coverage exceeds 75-85% municipal bylaws.
- **Essential Room Check**: Confirms mandatory living, washroom, and kitchen spaces exist for the requested house type.

### 4. Deterministic Construction Cost Estimator (BOQ)
- Uses an area-based quantity takeoff method benchmarked against prevailing CPWD / RICS standard residential rates.
- Itemized breakdown of **Civil Materials** (Cement, Steel rebar, Bricks/Blocks, Sand, Aggregate), **Finishing** (Flooring tiles, Paint, Doors & Windows), **Services** (Electrical, Plumbing), **Labour**, and **Contingency**.
- **In-line Unit Rate Customization**: Click any price cell in the BOQ table to test custom local contractor rates with live grand total re-estimation!
- **Budget Variance**: Visual comparison of target budget vs estimated total cost with surplus/deficit tracking.
- Export BOQ as **CSV**.

### 5. Local Project Archive
Save snapshots locally in browser storage, reopen past plans, rename projects, or import/export `.json` project files.

---

## 🏗️ Architecture & Technology Stack

```
                        ┌──────────────────────────────────────────────┐
                        │              User Web Browser                │
                        │  (React 19 + TypeScript + Tailwind CSS)      │
                        └──────┬────────────────────────────────┬──────┘
                               │                                │
                Vector SVG CAD │                                │ JSON Payloads
                Canvas & State │                                │
                               ▼                                ▼
                        ┌──────────────┐                 ┌──────────────┐
                        │ LocalStorage │                 │  server.ts   │
                        │ Persistence  │                 │  (Express)   │
                        └──────────────┘                 └──────┬───────┘
                                                                │
                                         ┌──────────────────────┼──────────────────────┐
                                         ▼                      ▼                      ▼
                                 ┌───────────────┐      ┌───────────────┐      ┌───────────────┐
                                 │ Google Gemma  │      │  Validation   │      │ Cost Estimator│
                                 │ 4 / GenAI API │      │ Engine (Geom) │      │  (CPWD BOQ)   │
                                 └───────────────┘      └───────────────┘      └───────────────┘
                                                                ▲
                                                                │ Optional API Proxy
                                                                ▼
                                                        ┌───────────────┐
                                                        │Python FastAPI │
                                                        │ (backend/app) │
                                                        └───────────────┘
```

- **Frontend**: React 19, TypeScript 7, Vite 8, Tailwind CSS v4, Lucide React, Canvas Confetti.
- **Backend**:
  - Node.js full-stack Express server (`server.ts`) for unified zero-config preview.
  - Python FastAPI backend (`backend/app/main.py`) with Pydantic schemas and pytest suites.
- **AI Inference**: `@google/genai` TypeScript SDK and `httpx` Python client connecting to Gemma 4 / Gemini models.

---

## 🚀 Getting Started

### Prerequisites
- Node.js >= 18
- Python >= 3.10 (optional, for running the standalone FastAPI backend and test suite)

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/planforge.git
cd planforge
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

To enable **Gemma AI Mode**, provide your Gemini / Gemma API key:
```env
GEMINI_API_KEY="your_api_key_here"
AI_MODEL="gemini-3.8-flash"
AI_PROVIDER="google_genai"
```
*(If no API key is set, PlanForge automatically activates Demo Mode without errors.)*

### 3. Start the Web Application
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. (Optional) Run the Standalone Python FastAPI Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Interactive FastAPI Swagger API docs will be accessible at [http://localhost:8000/docs](http://localhost:8000/docs).

---

## 🧪 Testing & Quality Verification

### Run Frontend TypeScript Compilation & Linter
```bash
npm run lint
npm run build
```

### Run Python Validation & Cost Unit Tests
```bash
pytest backend/tests
```
Tests verify:
- Accurate mathematical multiplication for all BOQ quantities and unit rates ($Subtotal = Qty \times Rate$).
- Conservation of totals with zero double-counting ($Total = Material + Labour + Services + Contingency$).
- Geometric pairwise collision detection between intersecting rooms.
- Detection of rooms extending outside plot boundaries.
- Resilient fallback when API keys are absent.

---

## 📋 Hackathon Benchmark Scenario

Try the official evaluation prompt in the application:

> *"I want a 2BHK house on a 30 by 40 feet plot, with two bedrooms, two bathrooms, a kitchen, a living room, and a small balcony. My budget is ₹20 lakhs."*

Click **"Load Benchmark 2BHK Preset"** on the home screen to test this exact scenario in one click.

---

## ⚠️ Scope Boundaries & Engineering Disclaimer

PlanForge is an architectural planning and cost estimation tool built for conceptual feasibility exploration. It is **not** a licensed structural engineering design, soil mechanics analysis, or binding contractor bid. Real-world construction requires site survey investigation, structural CAD reinforcement drawings, and statutory municipal sanction approvals.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
Gemma model weights and APIs are subject to the [Google Gemma Terms of Use](https://ai.google.dev/gemma/terms).
