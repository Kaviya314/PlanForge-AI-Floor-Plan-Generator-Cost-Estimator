from typing import List, Set, Tuple
from ..models.schemas import PlanLayoutSchema, ValidationResponse, ValidationErrorItem, ValidationChecks

def validate_layout_py(layout: PlanLayoutSchema) -> ValidationResponse:
    errors: List[ValidationErrorItem] = []
    warnings: List[ValidationErrorItem] = []

    plot = layout.plot
    rooms = layout.rooms

    dimensions_positive = True
    within_plot_boundary = True
    no_room_overlap = True
    unique_ids = True
    essential_rooms_present = True
    reasonable_coverage = True

    # 1. Plot dimensions check
    if plot.width <= 0 or plot.length <= 0:
        errors.append(ValidationErrorItem(
            id="err-plot-dim",
            field="plot",
            message="Plot width and length must both be strictly positive.",
            severity="error"
        ))
        dimensions_positive = False

    plot_area = max(0.0, plot.width * plot.length)
    total_room_area = 0.0

    # 2. Check room IDs and individual room dimensions
    seen_ids: Set[str] = set()

    for idx, room in enumerate(rooms):
        if not room.id:
            errors.append(ValidationErrorItem(
                id=f"err-room-no-id-{idx}",
                message=f"Room at position {idx} lacks a unique identifier.",
                severity="error"
            ))
            unique_ids = False
        elif room.id in seen_ids:
            errors.append(ValidationErrorItem(
                id=f"err-room-dup-{room.id}",
                roomId=room.id,
                roomName=room.name,
                message=f"Duplicate room identifier '{room.id}'. Each room must have a distinct ID.",
                severity="error"
            ))
            unique_ids = False
        else:
            seen_ids.add(room.id)

        if room.width <= 0 or room.length <= 0:
            errors.append(ValidationErrorItem(
                id=f"err-room-pos-{room.id}",
                roomId=room.id,
                roomName=room.name,
                message=f"Room '{room.name}' has non-positive dimensions ({room.width} x {room.length}).",
                severity="error"
            ))
            dimensions_positive = False

        r_area = max(0.0, room.width * room.length)
        total_room_area += r_area

        # Small room warning
        min_threshold = 3.0 if plot.unit == "m" else 30.0
        if room.type not in ["bathroom", "attached_bathroom", "balcony"] and r_area < min_threshold:
            warnings.append(ValidationErrorItem(
                id=f"warn-room-small-{room.id}",
                roomId=room.id,
                roomName=room.name,
                message=f"Room '{room.name}' area ({r_area:.1f} {plot.unit}²) is smaller than standard functional living standards.",
                severity="warning"
            ))

        # Boundary check
        r_right = room.x + room.width
        r_bottom = room.y + room.length
        eps = 0.05
        if room.x < -eps or room.y < -eps or r_right > plot.width + eps or r_bottom > plot.length + eps:
            errors.append(ValidationErrorItem(
                id=f"err-room-oob-{room.id}",
                roomId=room.id,
                roomName=room.name,
                message=f"Room '{room.name}' extends beyond plot limits [0,0] to [{plot.width},{plot.length}]. Room bounds: [{room.x:.1f},{room.y:.1f}] to [{r_right:.1f},{r_bottom:.1f}].",
                severity="error"
            ))
            within_plot_boundary = False

    # 3. Overlap collision detection
    eps_overlap = 0.05
    n = len(rooms)
    for i in range(n):
        for j in range(i + 1, n):
            r1 = rooms[i]
            r2 = rooms[j]
            f1 = r1.floor or 1
            f2 = r2.floor or 1
            if f1 != f2:
                continue

            r1_right = r1.x + r1.width
            r1_bottom = r1.y + r1.length
            r2_right = r2.x + r2.width
            r2_bottom = r2.y + r2.length

            overlaps_x = (r1.x < r2_right - eps_overlap) and (r1_right > r2.x + eps_overlap)
            overlaps_y = (r1.y < r2_bottom - eps_overlap) and (r1_bottom > r2.y + eps_overlap)

            if overlaps_x and overlaps_y:
                overlap_w = min(r1_right, r2_right) - max(r1.x, r2.x)
                overlap_h = min(r1_bottom, r2_bottom) - max(r1.y, r2.y)
                overlap_area = overlap_w * overlap_h
                errors.append(ValidationErrorItem(
                    id=f"err-overlap-{r1.id}-{r2.id}",
                    roomId=r1.id,
                    roomName=f"{r1.name} & {r2.name}",
                    message=f"Spatial collision: '{r1.name}' overlaps '{r2.name}' by ~{overlap_area:.1f} {plot.unit}².",
                    severity="error"
                ))
                no_room_overlap = False

    # 4. Coverage calculation
    coverage = (total_room_area / plot_area * 100) if plot_area > 0 else 0
    if coverage > 100:
        errors.append(ValidationErrorItem(
            id="err-coverage-exceeded",
            message=f"Total room carpet area ({total_room_area:.1f} {plot.unit}²) exceeds total plot area ({plot_area:.1f} {plot.unit}²). Coverage is {coverage:.1f}%.",
            severity="error"
        ))
        reasonable_coverage = False
    elif coverage > 85:
        warnings.append(ValidationErrorItem(
            id="warn-coverage-high",
            message=f"Plot coverage is {coverage:.1f}%. Municipal building bylaws typically require setbacks and wall space, keeping ground coverage below 75%.",
            severity="warning"
        ))

    # 5. Essential rooms presence
    room_types = {r.type for r in rooms}
    room_names = [r.name.lower() for r in rooms]

    has_kitchen = "kitchen" in room_types or any("kitchen" in n for n in room_names)
    has_bath = ("bathroom" in room_types or "attached_bathroom" in room_types or
                any("bath" in n or "toilet" in n or "wc" in n for n in room_names))

    if not has_kitchen:
        warnings.append(ValidationErrorItem(
            id="warn-no-kitchen",
            message="No designated kitchen area found in the plan.",
            severity="warning"
        ))
        essential_rooms_present = False

    if not has_bath:
        warnings.append(ValidationErrorItem(
            id="warn-no-bath",
            message="No designated bathroom or washroom found in the plan.",
            severity="warning"
        ))
        essential_rooms_present = False

    built_up_area = total_room_area * 1.18 * max(1, layout.floors)
    is_valid = len(errors) == 0

    return ValidationResponse(
        is_valid=is_valid,
        errors=errors,
        warnings=warnings,
        plot_area=round(plot_area, 1),
        total_room_area=round(total_room_area, 1),
        built_up_area=round(built_up_area, 1),
        coverage_percentage=round(coverage, 1),
        unit=plot.unit,
        checks=ValidationChecks(
            dimensions_positive=dimensions_positive,
            within_plot_boundary=within_plot_boundary,
            no_room_overlap=no_room_overlap,
            unique_ids=unique_ids,
            essential_rooms_present=essential_rooms_present,
            reasonable_coverage=reasonable_coverage
        )
    )
