from typing import List
from ..models.schemas import GeneratePlanRequest, PlanLayoutSchema, RoomSchema, PlotSchema, DoorSchema, WindowSchema

def generate_deterministic_plan_py(req: GeneratePlanRequest) -> PlanLayoutSchema:
    plot_width = float(req.plot_width) or 30.0
    plot_length = float(req.plot_length) or 40.0
    unit = req.unit or "ft"
    house_type = req.house_type or "2BHK"
    has_balcony = req.has_balcony if req.has_balcony is not None else True
    budget = float(req.budget_inr) or 2000000.0
    project_name = req.project_name or f"{house_type} Residence ({plot_width:.0f}x{plot_length:.0f} {unit})"

    # Usable setbacks
    setback_x = min(3.0, plot_width * 0.08) if plot_width >= 25 else 1.0
    setback_y = min(3.5, plot_length * 0.08) if plot_length >= 30 else 1.0

    usable_w = plot_width - setback_x * 2
    usable_l = plot_length - setback_y * 2

    rooms: List[RoomSchema] = []

    if house_type == "1BHK":
        col1_w = round(usable_w * 0.58, 1)
        col2_w = round(usable_w - col1_w, 1)
        row1_h = round(usable_l * 0.52, 1)
        row2_h = round(usable_l - row1_h, 1)

        rooms.append(RoomSchema(
            id="living-1", name="Living & Dining Room", type="living",
            x=setback_x, y=setback_y, width=col1_w, length=row1_h,
            doors=[DoorSchema(wall="bottom", offset=2.0, width=3.2)],
            windows=[WindowSchema(wall="top", offset=2.0, width=4.0)]
        ))
        rooms.append(RoomSchema(
            id="kitchen-1", name="Modular Kitchen", type="kitchen",
            x=setback_x + col1_w, y=setback_y, width=col2_w, length=round(row1_h * 0.7, 1),
            doors=[DoorSchema(wall="left", offset=2.0, width=2.8)],
            windows=[WindowSchema(wall="top", offset=2.0, width=3.0)]
        ))
        rooms.append(RoomSchema(
            id="bath-1", name="Common Washroom", type="bathroom",
            x=setback_x + col1_w, y=setback_y + round(row1_h * 0.7, 1), width=col2_w, length=round(row1_h * 0.3, 1),
            doors=[DoorSchema(wall="left", offset=1.5, width=2.5)],
            windows=[WindowSchema(wall="right", offset=1.0, width=2.0)]
        ))
        rooms.append(RoomSchema(
            id="bed-1", name="Master Bedroom", type="master_bedroom",
            x=setback_x, y=setback_y + row1_h, width=col1_w, length=row2_h,
            doors=[DoorSchema(wall="top", offset=2.0, width=3.0)],
            windows=[WindowSchema(wall="bottom", offset=2.0, width=4.0)]
        ))
        if has_balcony:
            rooms.append(RoomSchema(
                id="balcony-1", name="Sitout / Balcony", type="balcony",
                x=setback_x + col1_w, y=setback_y + row1_h, width=col2_w, length=row2_h,
                doors=[DoorSchema(wall="left", offset=2.0, width=2.8)],
                windows=[WindowSchema(wall="bottom", offset=1.5, width=3.0)]
            ))
    elif house_type == "3BHK":
        split_x = round(usable_w * 0.52, 1)
        right_x = round(usable_w - split_x, 1)
        row1_h = round(usable_l * 0.36, 1)
        row2_h = round(usable_l * 0.32, 1)
        row3_h = round(usable_l - row1_h - row2_h, 1)

        rooms.append(RoomSchema(
            id="living-1", name="Grand Living Hall", type="living",
            x=setback_x, y=setback_y, width=split_x, length=row1_h,
            doors=[DoorSchema(wall="bottom", offset=3.0, width=3.5)],
            windows=[WindowSchema(wall="top", offset=2.0, width=5.0)]
        ))
        rooms.append(RoomSchema(
            id="bed-3", name="Guest Bedroom", type="bedroom",
            x=setback_x + split_x, y=setback_y, width=right_x, length=row1_h,
            doors=[DoorSchema(wall="left", offset=2.0, width=3.0)],
            windows=[WindowSchema(wall="top", offset=2.0, width=3.5)]
        ))
        rooms.append(RoomSchema(
            id="kitchen-1", name="Kitchen & Dining", type="kitchen",
            x=setback_x, y=setback_y + row1_h, width=round(split_x * 0.65, 1), length=row2_h,
            doors=[DoorSchema(wall="top", offset=2.0, width=3.0)],
            windows=[WindowSchema(wall="left", offset=2.0, width=3.5)]
        ))
        rooms.append(RoomSchema(
            id="bath-1", name="Common Bath", type="bathroom",
            x=setback_x + round(split_x * 0.65, 1), y=setback_y + row1_h, width=round(split_x * 0.35, 1), length=row2_h,
            doors=[DoorSchema(wall="left", offset=1.5, width=2.5)],
            windows=[WindowSchema(wall="right", offset=1.0, width=2.0)]
        ))
        rooms.append(RoomSchema(
            id="bed-2", name="Bedroom 2", type="bedroom",
            x=setback_x + split_x, y=setback_y + row1_h, width=right_x, length=row2_h,
            doors=[DoorSchema(wall="left", offset=2.0, width=3.0)],
            windows=[WindowSchema(wall="right", offset=2.0, width=4.0)]
        ))
        rooms.append(RoomSchema(
            id="master-bed", name="Master Suite", type="master_bedroom",
            x=setback_x, y=setback_y + row1_h + row2_h, width=split_x, length=row3_h,
            doors=[DoorSchema(wall="top", offset=3.0, width=3.0)],
            windows=[WindowSchema(wall="bottom", offset=2.0, width=4.5)]
        ))
        rooms.append(RoomSchema(
            id="master-bath", name="Attached Bath", type="attached_bathroom",
            x=setback_x + split_x, y=setback_y + row1_h + row2_h, width=round(right_x * 0.45, 1), length=row3_h,
            doors=[DoorSchema(wall="left", offset=1.5, width=2.5)],
            windows=[WindowSchema(wall="right", offset=1.0, width=2.0)]
        ))
        if has_balcony:
            rooms.append(RoomSchema(
                id="balcony-1", name="Private Balcony", type="balcony",
                x=setback_x + split_x + round(right_x * 0.45, 1), y=setback_y + row1_h + row2_h,
                width=round(right_x * 0.55, 1), length=row3_h,
                doors=[DoorSchema(wall="left", offset=1.0, width=2.8)],
                windows=[WindowSchema(wall="bottom", offset=1.0, width=3.0)]
            ))
    else:
        # Default 2BHK Layout
        left_w = round(usable_w * 0.52, 1)
        right_w = round(usable_w - left_w, 1)
        front_h = round(usable_l * 0.48, 1)
        rear_h = round(usable_l - front_h, 1)

        rooms.append(RoomSchema(
            id="room-living", name="Living Room", type="living",
            x=setback_x, y=setback_y, width=left_w, length=front_h,
            doors=[DoorSchema(wall="bottom", offset=2.5, width=3.5)],
            windows=[
                WindowSchema(wall="top", offset=2.0, width=4.0),
                WindowSchema(wall="left", offset=2.5, width=4.0)
            ]
        ))

        rooms.append(RoomSchema(
            id="room-bed-2", name="Bedroom 2", type="bedroom",
            x=setback_x + left_w, y=setback_y, width=right_w, length=round(front_h * 0.72, 1),
            doors=[DoorSchema(wall="bottom", offset=2.0, width=3.0)],
            windows=[
                WindowSchema(wall="top", offset=2.0, width=3.5),
                WindowSchema(wall="right", offset=2.0, width=3.5)
            ]
        ))

        bath_h = round(front_h * 0.28, 1)
        rooms.append(RoomSchema(
            id="room-bath-common", name="Common Bath", type="bathroom",
            x=setback_x + left_w, y=setback_y + round(front_h * 0.72, 1),
            width=right_w, length=bath_h,
            doors=[DoorSchema(wall="left", offset=1.5, width=2.5)],
            windows=[WindowSchema(wall="right", offset=1.0, width=2.0)]
        ))

        kit_l = round(rear_h * 0.72, 1) if has_balcony else rear_h
        rooms.append(RoomSchema(
            id="room-kitchen", name="Kitchen & Dining", type="kitchen",
            x=setback_x, y=setback_y + front_h, width=left_w, length=kit_l,
            doors=[DoorSchema(wall="top", offset=2.0, width=3.0)],
            windows=[
                WindowSchema(wall="left", offset=2.0, width=3.5),
                WindowSchema(wall="bottom", offset=2.0, width=3.5)
            ]
        ))

        if has_balcony:
            rooms.append(RoomSchema(
                id="room-balcony", name="Balcony / Sitout", type="balcony",
                x=setback_x, y=setback_y + front_h + kit_l, width=left_w, length=round(rear_h - kit_l, 1),
                doors=[DoorSchema(wall="top", offset=2.0, width=2.8)],
                windows=[WindowSchema(wall="bottom", offset=1.5, width=4.0)]
            ))

        master_bath_w = round(right_w * 0.42, 1)
        master_bed_w = round(right_w - master_bath_w, 1)

        rooms.append(RoomSchema(
            id="room-master-bed", name="Master Bedroom", type="master_bedroom",
            x=setback_x + left_w, y=setback_y + front_h, width=master_bed_w, length=rear_h,
            doors=[DoorSchema(wall="left", offset=2.0, width=3.0)],
            windows=[
                WindowSchema(wall="bottom", offset=2.0, width=4.0),
                WindowSchema(wall="right", offset=2.0, width=4.0)
            ]
        ))

        rooms.append(RoomSchema(
            id="room-master-bath", name="Attached Bath", type="attached_bathroom",
            x=setback_x + left_w + master_bed_w, y=setback_y + front_h, width=master_bath_w, length=rear_h,
            doors=[DoorSchema(wall="left", offset=2.0, width=2.5)],
            windows=[WindowSchema(wall="right", offset=1.5, width=2.0)]
        ))

    return PlanLayoutSchema(
        project_name=project_name,
        plot=PlotSchema(width=plot_width, length=plot_length, unit=unit),
        rooms=rooms,
        floors=req.floors or 1,
        house_type=house_type,
        budget_inr=budget,
        design_notes=[
            "Demo Mode: Layout synthesized via deterministic architectural layout heuristics.",
            f"Setbacks: {setback_x} {unit} side clearance, {setback_y} {unit} front road approach.",
            "Zoning: Public entertainment zones positioned in front; quiet bedroom suites buffered in rear.",
            "Cross-ventilation: External walls feature daylight fenestrations on opposing walls."
        ],
        mode="demo",
        ai_explanation="Plan generated via PlanForge deterministic rule engine. Guaranteed collision-free room bounds and standard setbacks."
    )
