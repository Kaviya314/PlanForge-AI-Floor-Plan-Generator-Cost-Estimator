import os
import re
import json
import httpx
from typing import Optional, Tuple
from ..models.schemas import GeneratePlanRequest, PlanLayoutSchema, RoomSchema, PlotSchema
from .layout_service import generate_deterministic_plan_py

API_KEY = os.getenv("GEMMA_API_KEY") or os.getenv("GEMINI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "gemma-4-26b-a4b-it")

def extract_json_py(raw_text: str) -> dict:
    text = (raw_text or "").strip()
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text)
    if match:
        text = match.group(1).strip()
    return json.loads(text)

async def generate_plan_ai(req: GeneratePlanRequest) -> Tuple[PlanLayoutSchema, str, bool]:
    """
    Generates floor plan via Google AI Studio supported Gemma 4 / GenAI API.
    Returns (plan, status_message, is_demo_fallback)
    """
    has_key = bool(API_KEY and API_KEY not in ["MY_GEMINI_API_KEY", "MY_GEMMA_API_KEY"])
    force_demo = req.force_demo or not has_key

    if force_demo:
        plan = generate_deterministic_plan_py(req)
        return plan, "Generated in Demo Mode (deterministic rules)", True

    prompt = f"""You are PlanForge's architectural planning engine powered by Google Gemma 4.
Convert these requirements into a preliminary 2D residential floor plan:
- Natural Description: "{req.natural_prompt or ''}"
- Project Name: "{req.project_name or 'Residence'}"
- Plot Dimensions: {req.plot_width} {req.unit} width x {req.plot_length} {req.unit} length. Total Area: {req.plot_width * req.plot_length} {req.unit}².
- House Type: {req.house_type}
- Bedrooms: {req.num_bedrooms}, Bathrooms: {req.num_bathrooms}, Kitchens: {req.num_kitchens}, Living Rooms: {req.num_living_rooms}, Balcony: {req.has_balcony}
- Target Budget: ₹{req.budget_inr} INR

GEOMETRIC RULES:
1. Every room must have positive width and length.
2. Every room must be positioned strictly within plot boundaries: x >= 0, y >= 0, (x + width) <= {req.plot_width}, (y + length) <= {req.plot_length}.
3. Rooms must NOT overlap each other.
4. Output valid JSON with fields: project_name, plot (width, length, unit), rooms (list of id, name, type, x, y, width, length), budget_inr, design_notes, ai_explanation."""

    try:
        # Call Google AI Studio / Gemini endpoint directly via HTTP
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{AI_MODEL}:generateContent?key={API_KEY}"
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "responseMimeType": "application/json",
                "temperature": 0.2
            }
        }

        async with httpx.AsyncClient(timeout=45.0) as client:
            resp = await client.post(url, json=payload, headers={"User-Agent": "aistudio-build"})
            if resp.status_code != 200:
                raise Exception(f"AI API returned status {resp.status_code}: {resp.text[:200]}")

            data = resp.json()
            raw_text = data["candidates"][0]["content"]["parts"][0]["text"]
            parsed = extract_json_py(raw_text)

            rooms = []
            for idx, r in enumerate(parsed.get("rooms", [])):
                w = max(2.0, float(r.get("width", 10.0)))
                l = max(2.0, float(r.get("length", 10.0)))
                rooms.append(RoomSchema(
                    id=r.get("id", f"room-{idx+1}"),
                    name=r.get("name", f"Room {idx+1}"),
                    type=r.get("type", "custom"),
                    x=max(0.0, float(r.get("x", 0.0))),
                    y=max(0.0, float(r.get("y", 0.0))),
                    width=w,
                    length=l,
                    doors=[],
                    windows=[]
                ))

            plan = PlanLayoutSchema(
                project_name=parsed.get("project_name", req.project_name or "Gemma 4 Floor Plan"),
                plot=PlotSchema(
                    width=float(parsed.get("plot", {}).get("width", req.plot_width)),
                    length=float(parsed.get("plot", {}).get("length", req.plot_length)),
                    unit=req.unit
                ),
                rooms=rooms,
                floors=req.floors or 1,
                house_type=req.house_type,
                budget_inr=float(parsed.get("budget_inr", req.budget_inr)),
                design_notes=parsed.get("design_notes", ["Gemma 4 synthesized layout based on user prompt."]),
                mode="ai",
                ai_model_used=AI_MODEL,
                ai_explanation=parsed.get("ai_explanation", "Plan synthesized using Google Gemma 4 spatial reasoning.")
            )
            return plan, "Successfully generated via Gemma 4", False

    except Exception as e:
        fallback = generate_deterministic_plan_py(req)
        return fallback, f"AI generation fallback to Demo Mode: {str(e)}", True
