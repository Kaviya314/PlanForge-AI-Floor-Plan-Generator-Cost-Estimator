from datetime import datetime
from typing import Dict, Optional, List
from ..models.schemas import PlanLayoutSchema, CostEstimateResponse, MaterialCostItemSchema

def calculate_cost_estimate_py(
    layout: PlanLayoutSchema,
    rate_overrides: Optional[Dict[str, float]] = None
) -> CostEstimateResponse:
    if rate_overrides is None:
        rate_overrides = {}

    plot = layout.plot
    rooms = layout.rooms
    floors = max(1, layout.floors)
    budget_inr = layout.budget_inr or 2000000.0

    # 1. Total Carpet Area
    carpet_area = sum(max(0.0, r.width) * max(0.0, r.length) for r in rooms)
    is_meters = plot.unit == "m"
    carpet_area_sqft = carpet_area * 10.7639 if is_meters else carpet_area

    # Built-up area includes 18% allowance for exterior brick walls, partitions, and circulation
    built_up_area_sqft = max(1.0, carpet_area_sqft * 1.18 * floors)
    built_up_area_sqm = built_up_area_sqft / 10.7639

    # Standard empirical rates and quantities per sq.ft built-up area
    raw_specs = [
        ("cement", "civil", "Cement (OPC / PPC 53 Grade)", "For RCC columns, beams, slab casting & brickwork", "bags (50kg)", round(built_up_area_sqft * 0.4), 380.0, "0.40 bags per sq.ft built-up area"),
        ("steel", "civil", "TMT Structural Steel (Fe-550D)", "High yield rebar for earthquake-resistant frame", "kg", round(built_up_area_sqft * 3.8), 68.0, "3.8 kg per sq.ft built-up area"),
        ("bricks", "civil", "Red Clay Bricks / AAC Blocks", "9\" exterior and 4.5\" interior partition walls", "units", round(built_up_area_sqft * 18), 9.0, "18 bricks per sq.ft"),
        ("sand", "civil", "Manufactured / River Sand (M-Sand)", "Screened sand for concrete mix and plastering", "cft", round(built_up_area_sqft * 1.75), 55.0, "1.75 cubic feet per sq.ft"),
        ("aggregate", "civil", "Coarse Aggregate (20mm & 10mm)", "Crushed blue granite stone aggregate", "cft", round(built_up_area_sqft * 1.3), 42.0, "1.30 cubic feet per sq.ft"),
        ("flooring", "finishing", "Vitrified Tiles & Anti-skid Flooring", "Double-charge 2x2 vitrified tiles with 10% wastage allowance", "sq.ft", round(built_up_area_sqft * 1.12), 85.0, "1.12 x built-up area"),
        ("painting", "finishing", "Internal & External Painting", "Wall putty, 1 coat primer, 2 coats acrylic emulsion", "sq.ft surface", round(built_up_area_sqft * 3.2), 22.0, "3.2 x floor area wall surface"),
        ("doors_windows", "finishing", "Doors & Windows (Teak / UPVC)", "Main door + flush interior doors + 2-track UPVC windows", "sq.ft built-up", round(built_up_area_sqft), 95.0, "₹95 per sq.ft built-up area"),
        ("electrical", "services", "Electrical Conduiting, Wiring & DB", "FR copper wiring, modular switch plates, distribution board", "sq.ft built-up", round(built_up_area_sqft), 75.0, "₹75 per sq.ft built-up area"),
        ("plumbing", "services", "Plumbing, Drainage & Sanitaryware", "CPVC water supply, PVC drainage, EWC toilets, fittings", "sq.ft built-up", round(built_up_area_sqft), 70.0, "₹70 per sq.ft built-up area"),
        ("labour_civil", "labour", "Civil Structural Labour (RCC & Masonry)", "Excavation, bar bending, formwork shuttering & brickwork", "sq.ft built-up", round(built_up_area_sqft), 280.0, "₹280 per sq.ft contractor rate"),
        ("labour_finishing", "labour", "Finishing Labour (Plaster, Tile & Paint)", "Skilled plasterers, tile masons, electricians, painters", "sq.ft built-up", round(built_up_area_sqft), 125.0, "₹125 per sq.ft finishing labour"),
    ]

    items: List[MaterialCostItemSchema] = []
    material_subtotal = 0.0
    labour_subtotal = 0.0
    finishing_services_subtotal = 0.0

    for item_id, cat, name, spec, unit, qty, def_rate, notes in raw_specs:
        rate = rate_overrides.get(item_id, def_rate)
        subtotal = round(qty * rate)

        if cat == "civil":
            material_subtotal += subtotal
        elif cat in ["finishing", "services"]:
            finishing_services_subtotal += subtotal
        elif cat == "labour":
            labour_subtotal += subtotal

        status = "user_modified" if item_id in rate_overrides else "default_benchmark"
        items.append(MaterialCostItemSchema(
            id=item_id,
            category=cat,
            name=name,
            specification=spec,
            unit=unit,
            quantity=qty,
            unit_rate=rate,
            subtotal=subtotal,
            status=status,
            formula_notes=notes
        ))

    base_subtotal = material_subtotal + finishing_services_subtotal + labour_subtotal
    contingency_amount = round(base_subtotal * 0.045)

    items.append(MaterialCostItemSchema(
        id="contingency",
        category="contingency",
        name="Statutory Approvals & Site Contingency",
        specification="Temporary utility connections, municipal plan scrutiny, site variances",
        unit="lump sum (4.5%)",
        quantity=1,
        unit_rate=contingency_amount,
        subtotal=contingency_amount,
        status="default_benchmark",
        formula_notes="4.5% contingency buffer on primary execution costs"
    ))

    grand_total = base_subtotal + contingency_amount
    cost_per_sqft = round(grand_total / built_up_area_sqft) if built_up_area_sqft > 0 else 0
    budget_variance = budget_inr - grand_total
    budget_utilized = (grand_total / budget_inr * 100) if budget_inr > 0 else 0

    return CostEstimateResponse(
        built_up_area_sqft=round(built_up_area_sqft),
        built_up_area_sqm=round(built_up_area_sqm, 1),
        carpet_area_sqft=round(carpet_area_sqft),
        floors=floors,
        items=items,
        material_cost_total=material_subtotal,
        labour_cost_total=labour_subtotal,
        finishing_services_total=finishing_services_subtotal,
        contingency_total=contingency_amount,
        grand_total=grand_total,
        cost_per_sqft=cost_per_sqft,
        budget_inr=budget_inr,
        budget_variance=budget_variance,
        budget_utilized_percentage=round(budget_utilized, 1),
        assumptions=[
            "Estimates are based on standard RCC Framed Structure with brick infill walls on normal soil conditions.",
            "Built-up area includes carpet area plus an 18% allowance for exterior walls, partition walls, and circulation corridors.",
            "Unit rates reflect current prevailing metro/tier-2 construction benchmarks in INR and can be adjusted.",
            "Cost does not include land purchase, deep piling/basement foundation, or custom luxury interior woodwork."
        ],
        disclaimer="PRELIMINARY ESTIMATE NOTICE: This estimate is computed using parametric area-based benchmarks for conceptual planning only. It is not an engineering quantity bill (BOQ) or a binding contractor quotation.",
        timestamp=datetime.utcnow().isoformat()
    )
