from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Dict

class PlotSchema(BaseModel):
    width: float = Field(..., gt=0, description="Plot width in specified units")
    length: float = Field(..., gt=0, description="Plot length in specified units")
    unit: Literal["ft", "m"] = "ft"

class DoorSchema(BaseModel):
    wall: Literal["top", "bottom", "left", "right"]
    offset: float
    width: float

class WindowSchema(BaseModel):
    wall: Literal["top", "bottom", "left", "right"]
    offset: float
    width: float

class RoomSchema(BaseModel):
    id: str
    name: str
    type: str = "custom"
    x: float
    y: float
    width: float = Field(..., gt=0)
    length: float = Field(..., gt=0)
    floor: Optional[int] = 1
    doors: Optional[List[DoorSchema]] = []
    windows: Optional[List[WindowSchema]] = []

class PlanLayoutSchema(BaseModel):
    project_name: str
    plot: PlotSchema
    rooms: List[RoomSchema]
    floors: int = 1
    house_type: str = "2BHK"
    budget_inr: float = 2000000.0
    design_notes: List[str] = []
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    mode: Literal["ai", "demo"] = "demo"
    ai_model_used: Optional[str] = None
    ai_explanation: Optional[str] = None

class GeneratePlanRequest(BaseModel):
    natural_prompt: Optional[str] = None
    project_name: Optional[str] = None
    plot_width: float = Field(30.0, gt=0)
    plot_length: float = Field(40.0, gt=0)
    unit: Literal["ft", "m"] = "ft"
    house_type: str = "2BHK"
    num_bedrooms: int = 2
    num_bathrooms: int = 2
    num_kitchens: int = 1
    num_living_rooms: int = 1
    has_balcony: bool = True
    floors: int = 1
    design_style: Optional[str] = "Modern Vastu"
    budget_inr: float = 2000000.0
    force_demo: Optional[bool] = False

class ValidationErrorItem(BaseModel):
    id: str
    field: Optional[str] = None
    roomId: Optional[str] = None
    roomName: Optional[str] = None
    message: str
    severity: Literal["error", "warning", "info"]

class ValidationChecks(BaseModel):
    dimensions_positive: bool
    within_plot_boundary: bool
    no_room_overlap: bool
    unique_ids: bool
    essential_rooms_present: bool
    reasonable_coverage: bool

class ValidationResponse(BaseModel):
    is_valid: bool
    errors: List[ValidationErrorItem]
    warnings: List[ValidationErrorItem]
    plot_area: float
    total_room_area: float
    built_up_area: float
    coverage_percentage: float
    unit: str
    checks: ValidationChecks

class MaterialCostItemSchema(BaseModel):
    id: str
    category: Literal["civil", "finishing", "services", "labour", "contingency"]
    name: str
    specification: str
    unit: str
    quantity: float
    unit_rate: float
    subtotal: float
    status: Literal["default_benchmark", "user_modified"]
    formula_notes: str

class CostEstimateResponse(BaseModel):
    built_up_area_sqft: float
    built_up_area_sqm: float
    carpet_area_sqft: float
    floors: int
    items: List[MaterialCostItemSchema]
    material_cost_total: float
    labour_cost_total: float
    finishing_services_total: float
    contingency_total: float
    grand_total: float
    cost_per_sqft: float
    budget_inr: float
    budget_variance: float
    budget_utilized_percentage: float
    assumptions: List[str]
    disclaimer: str
    timestamp: str

class CostEstimateRequest(BaseModel):
    layout: PlanLayoutSchema
    rate_overrides: Optional[Dict[str, float]] = {}

class AIExplanationRequest(BaseModel):
    layout: PlanLayoutSchema
    query: Optional[str] = None
